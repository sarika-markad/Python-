# custom_calc.py

# Addition: Sum all elements in the list
def addition(numbers):
    return sum(numbers)

# Subtraction: Subtract all elements from the first one
def subtraction(numbers):
    if not numbers:
        return 0
    result = numbers[0]
    for num in numbers[1:]:
        result -= num
    return result

# Multiplication: Multiply all elements together
def multiplication(numbers):
    result = 1
    for num in numbers:
        result *= num
    return result

# Division: Divide first element by second, then result by third, etc.
def division(numbers):
    if not numbers:
        return None
    result = numbers[0]
    for num in numbers[1:]:
        if num == 0:
            raise ValueError("Cannot divide by zero")
        result /= num
    return result

# Power: Raise first element to second, then result to third, etc.
def power(numbers):
    if not numbers:
        return None
    result = numbers[0]
    for num in numbers[1:]:
        result = result ** num
    return result
